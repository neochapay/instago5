// *************************************************** //
// Datacache Script
//
// This script provides general caching mechanisms for
// images and users.
// Note that all data caches are cleared once the
// application starts so it's only valid for one
// session.
// The cached data will be stored in the local
// app database (tables: imagecache, usercache).
// *************************************************** //

// TODO: this is a stub!
