.pragma library

var instagramClientId = "3bbd61a332384e66a46026c3dbbfaadc";
var instagramClientSecret = "";
