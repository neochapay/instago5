.pragma library

var currentApplicationVersion = "0.3.0 (Public Beta)";

