.pragma library

var currentGalleryContent = [];
var currentGalleryIndex = 0;
var currentUserId = 0;
