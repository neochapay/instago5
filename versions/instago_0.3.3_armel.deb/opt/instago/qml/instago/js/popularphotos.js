// *************************************************** //
// Popularphotos Script
//
// This script is used to load, format and show the
// popular image feed.
// It's used by the PopularPhotosPage.
// *************************************************** //


// include other scripts used here
Qt.include("instagramkeys.js");
Qt.include("authenticationhandler.js");
Qt.include("helpermethods.js");
Qt.include("networkhandler.js");

// general network handler that acts upon the http request
var network = new NetworkHandler();

// general authentication handler that provides user authentication methods
var auth = new AuthenticationHandler();


// load the popular image stream from Instagram
// the image data will be used to fill the standard ImageGallery component
function loadImages()
{
    // console.log("Loading popular photos");

    // clear feed list
    imageGallery.clearGallery();

    var req = new XMLHttpRequest();
    req.onreadystatechange = function()
            {
                // this handles the result for each ready state
                var jsonObject = network.handleHttpResult(req);

                // jsonObject contains either false or the http result as object
                if (jsonObject)
                {
                    var imageCache = new Array();
                    for ( var index in jsonObject.data )
                    {
                        if (index <= 17)
                        {
                            // get image object
                            imageCache = getImageDataFromObject(jsonObject.data[index]);
                            // cacheImage(imageCache);

                            // add image object to gallery list
                            imageGallery.addToGallery({
                                                        "url":imageCache["thumbnail"],
                                                        "index":imageCache["imageid"]
                                                    });

                            // console.log("Appended list with URL: " + imageCache["thumbnail"] + " and ID: " + imageCache["imageid"]);
                        }
                    }

                    loadingIndicator.running = false;
                    loadingIndicator.visible = false;
                    imageGallery.visible = true;

                    // console.log("Done loading popular photos");
                }
                else
                {
                    // either the request is not done yet or an error occured
                    // check for both and act accordingly
                    if ( (network.requestIsFinished) && (network.errorData['code'] != null) )
                    {
                        loadingIndicator.running = false;
                        loadingIndicator.visible = false;

                        errorMessage.showErrorMessage({
                                                          "d_code":network.errorData['code'],
                                                          "d_error_type":network.errorData['error_type'],
                                                          "d_error_message":network.errorData['error_message']
                                                      });
                    }
                }
            }

    req.open("GET", "https://api.instagram.com/v1/media/popular?client_id=" + instagramClientId, true);
    req.send();
}
