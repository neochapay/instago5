.pragma library

// these are the keys for the Instagram client
// get them here: http://instagram.com/developer/clients/manage/
// (you need to be logged into Instagram to create apps)

// Instagram client id
var instagramClientId = "3bbd61a332384e66a46026c3dbbfaadc";

// Instagram client secret
var instagramClientSecret = "aa0cec4e9bbc400f908520b814e9e5b8";

// Instagram URL the user authenticates against
var instagramAuthorizeUrl = "https://api.instagram.com/oauth/authorize";

// Instagram URL to request a permanent token
var instagramTokenRequestUrl = "https://api.instagram.com/oauth/access_token";

// Instagram redirect URL
var instagramRedirectUrl = "http://www.instago.mobi";
