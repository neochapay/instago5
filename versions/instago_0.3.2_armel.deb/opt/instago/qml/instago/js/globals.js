// *************************************************** //
// Globals
//
// This file contains globally relevant variables.
// Note that the var content is stable (making them
// constants - if there was such a thing in JS).
// *************************************************** //

.pragma library

var currentApplicationVersion = "0.3.2 (Developer Build)";

