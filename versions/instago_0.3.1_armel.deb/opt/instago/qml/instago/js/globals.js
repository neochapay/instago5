.pragma library

var currentApplicationVersion = "0.3.1 (Developer Build)";

